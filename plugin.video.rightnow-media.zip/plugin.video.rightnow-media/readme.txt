Unoffical RightNow Media Kodi plugin.
Set email and password in the plugin settings.
